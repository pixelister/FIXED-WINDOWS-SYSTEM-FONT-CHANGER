Welcome and thank you for downloading my registry editor font changers! all you have to do is:
1. run one of them
2. allow changes to your device
3. restart for the system font to change.
-------------------------------------------------------------------------------------------------------------------------------------------
here are my socials to get in contact with me for any suggestions
roblox: hallucination190 (i do friendly exploiting on there like making people laugh etc)
TIKTOK:  pixelister12
discord: .wlrd
-------------------------------------------------------
If you would like to create a regstry file yourself then here is the text to copy:
-
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts]
"Segoe UI (TrueType)"=""
"Segoe UI Bold (TrueType)"=""
"Segoe UI Bold Italic (TrueType)"=""
"Segoe UI Italic (TrueType)"=""
"Segoe UI Light (TrueType)"=""
"Segoe UI Semibold (TrueType)"=""
"Segoe UI Symbol (TrueType)"=""
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\FontSubstitutes]
"Segoe UI"="NEW-FONT"
-